
import Header from './Header.jsx'
import Footer from './Footer.jsx'
import Food from './Food.jsx'
import Card from './Card.jsx'
import Endgame from './Endgame.jsx'


function App() {

  return (
    <>
      <Header/>
      <Food/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <hr></hr>
      <h1>ຜົນການແຂ່ງຂັນ</h1>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>
      <Endgame text="ບານເຕະຊາຍ" text1="ບານເຕະຊາຍ ຮອບຊີງຊະນະເລີດ" text2="ນັດທີ່ 20 13/5/2024 16:00" text3="ວຄທ 2 ພົບກັບ 1 ມສ"/>


      <hr></hr>
      <Footer/>
    </>
    
  )
}

export default App
