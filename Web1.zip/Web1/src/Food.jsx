
function Food(){

    return (
        <ul>
            <li><h1>ຕາຕະລາງປະຈໍາວັນ</h1></li>
        </ul>
    );
}

export default Food