
import styles from './Button.module.css'

function Button(){

    return(
        <button className={styles.button}>ເບິ່ລາຍລະອຽດ</button>
    );
}

export default Button